#!/usr/bin/env python3

import os
import subprocess
from datetime import datetime

# Configuration
DB_HOST = 'localhost'
DB_USER = 'your_username'
DB_PASSWORD = 'your_password'
DB_NAME = 'your_database'
BACKUP_DIR = '/path/to/backup_dir'


def ensure_backup_dir(path):
    """Make sure the backup directory exists."""
    os.makedirs(path, exist_ok=True)


def make_backup():
    """Run mysqldump and write to a timestamped file."""
    # 1. Build a unique filename using current date/time
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"{DB_NAME}_backup_{timestamp}.sql"
    filepath = os.path.join(BACKUP_DIR, filename)

    # 2. Construct the mysqldump command
    cmd = [
        'mysqldump',
        f'-h{DB_HOST}',
        f'-u{DB_USER}',
        f'-p{DB_PASSWORD}',
        DB_NAME,
    ]

    with open(filepath, 'w') as f:
        result = subprocess.run(
            cmd,
            stdout=f,
            stderr=subprocess.PIPE,
            text=True,
        )

    # 4. Check for errors
    if result.returncode == 0:
        print(f"Backup successful: {filepath}")
    else:
        print("Backup failed:", result.stderr)


if __name__ == '__main__':
    ensure_backup_dir(BACKUP_DIR)
    make_backup()

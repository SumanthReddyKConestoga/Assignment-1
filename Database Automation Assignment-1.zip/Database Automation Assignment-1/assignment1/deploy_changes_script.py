#!/usr/bin/env python3
import mysql.connector
from mysql.connector import errorcode

# —— Configuration ——
DB_CONFIG = {
    'host':     'localhost',
    'user':     'your_username',
    'password': 'your_password',
    'database': 'your_database',
    'raise_on_warnings': True
}

# List your schema changes here, in order
SQL_CHANGES = [
    # Example: add a new table
    """
    CREATE TABLE IF NOT EXISTS customers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE
    );
    """,
    # Example: add a new column
    "ALTER TABLE orders ADD COLUMN order_status VARCHAR(20) DEFAULT 'pending';"
]


def deploy_changes():
    """Connect to MySQL and run each change script in sequence."""
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor()
        for sql in SQL_CHANGES:
            print("Applying change:")
            print(sql.strip().split('\n')[0] + ' …')
            cursor.execute(sql)
        conn.commit()
        print("All changes applied successfully.")
    except mysql.connector.Error as err:
        # Handle common errors
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("Warning: Tried to create a table that already exists.")
        else:
            print("Error deploying changes:", err)
    finally:
        cursor.close()
        conn.close()


if __name__ == '__main__':
    deploy_changes()
